
import * as React from 'react';
import { Link } from 'react-router-dom';
import { FOOTER_LINKS } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-dark-card border-t border-dark-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-center md:text-left">
            <p className="text-sm text-medium-text">
              © {new Date().getFullYear()} SnapTikHD. All rights reserved.
            </p>
            <p className="text-xs text-medium-text mt-1">
              We are not affiliated with TikTok or Bytedance. We do not host any videos on our servers.
            </p>
          </div>
          <div className="flex space-x-6">
            {FOOTER_LINKS.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className="text-sm text-medium-text hover:text-primary transition-colors duration-300"
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;