
import * as React from 'react';
import type { DownloadResult } from '../types';

interface DownloadResultProps {
  result: DownloadResult;
  onReset: () => void;
}

const DownloadResultCard: React.FC<DownloadResultProps> = ({ result, onReset }) => {
  return (
    <div className="w-full max-w-2xl mx-auto bg-dark-card border border-dark-border rounded-lg p-6 animate-fade-in">
      <div className="flex flex-col md:flex-row gap-6">
        <img
          src={result.thumbnailUrl}
          alt="Video thumbnail"
          className="w-full md:w-48 h-auto object-cover rounded-md"
        />
        <div className="flex-1">
          <p className="text-medium-text text-sm">@{result.author}</p>
          <h3 className="text-light-text font-semibold mt-1 line-clamp-2">{result.title}</h3>
          <div className="mt-4 space-y-3">
             <a
              href={result.hdVideoUrl}
              download
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-3 text-center bg-primary text-dark-bg font-bold py-3 px-4 rounded-lg hover:bg-opacity-80 transition-all duration-300"
            >
              <i className="fas fa-video"></i>
              <span>Download Video (HD)</span>
            </a>
            <a
              href={result.videoUrl}
              download
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-3 text-center bg-dark-border text-light-text font-bold py-3 px-4 rounded-lg hover:bg-opacity-80 transition-all duration-300"
            >
              <i className="fas fa-film"></i>
              <span>Download Video (SD)</span>
            </a>
            <a
              href={result.mp3Url}
              download
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-3 text-center bg-secondary text-light-text font-bold py-3 px-4 rounded-lg hover:bg-opacity-80 transition-all duration-300"
            >
              <i className="fas fa-music"></i>
              <span>Download MP3</span>
            </a>
          </div>
        </div>
      </div>
      <div className="mt-6 text-center">
        <button onClick={onReset} className="text-primary hover:underline">
          Download another video
        </button>
      </div>
    </div>
  );
};

export default DownloadResultCard;