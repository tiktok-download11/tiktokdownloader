
import * as React from 'react';

interface AdPlaceholderProps {
  width: string;
  height: string;
  className?: string;
  label?: string;
}

const AdPlaceholder: React.FC<AdPlaceholderProps> = ({ width, height, className = '', label = 'Advertisement' }) => {
  return (
    <div
      className={`bg-dark-border/50 border-2 border-dashed border-gray-600 flex items-center justify-center ${className}`}
      style={{ width: width, height: height }}
    >
      <span className="text-gray-500 text-sm">{label} ({width}x{height})</span>
    </div>
  );
};

export default AdPlaceholder;