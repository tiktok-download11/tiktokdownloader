
import * as React from 'react';

interface DownloadFormProps {
  isLoading: boolean;
  onDownload: (url: string) => void;
}

const DownloadForm: React.FC<DownloadFormProps> = ({ isLoading, onDownload }) => {
  const [url, setUrl] = React.useState('');

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text);
    } catch (err) {
      console.error('Failed to read clipboard contents: ', err);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onDownload(url);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl mx-auto">
      <div className="relative flex flex-col sm:flex-row items-center gap-2">
        <div className="relative w-full">
            <i className="fas fa-link absolute left-4 top-1/2 -translate-y-1/2 text-medium-text"></i>
            <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Paste TikTok video URL here"
            className="w-full bg-dark-card border-2 border-dark-border rounded-full py-4 pl-12 pr-24 sm:pr-32 text-light-text focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-all duration-300"
            disabled={isLoading}
            />
            <button
                type="button"
                onClick={handlePaste}
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-dark-border text-primary font-semibold px-3 py-2 rounded-full hover:bg-primary hover:text-dark-bg transition-colors duration-300 hidden sm:block"
                disabled={isLoading}
            >
                Paste
            </button>
        </div>
        <button
          type="submit"
          className="w-full sm:w-auto bg-gradient-to-r from-primary to-secondary text-dark-bg font-bold py-4 px-8 rounded-full hover:scale-105 transform transition-transform duration-300 flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={isLoading}
        >
          {isLoading ? (
            <React.Fragment>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <span>Processing...</span>
            </React.Fragment>
          ) : (
            <React.Fragment>
              <i className="fas fa-download"></i>
              <span>Download</span>
            </React.Fragment>
          )}
        </button>
      </div>
    </form>
  );
};

export default DownloadForm;