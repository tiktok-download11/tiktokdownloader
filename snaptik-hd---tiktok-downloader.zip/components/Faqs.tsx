
import * as React from 'react';

const FAQ_DATA = [
  {
    question: 'Is it free to use this TikTok downloader?',
    answer: 'Yes, our service is completely free. We cover our costs through advertisements, allowing you to download unlimited TikTok videos without any charges.'
  },
  {
    question: 'Do I need to install any software or extensions?',
    answer: 'No, our tool is 100% web-based. You don\'t need to install anything on your computer or mobile phone. All you need is a web browser and a TikTok video link.'
  },
  {
    question: 'Can I download videos without the watermark?',
    answer: 'Absolutely! This is our main feature. All videos are downloaded in their original form without the TikTok logo or watermark, providing you with a clean, high-quality video.'
  },
  {
    question: 'Is it legal to download TikTok videos?',
    answer: 'Downloading videos is generally permissible for personal use and offline viewing. However, you must respect copyright laws. Do not re-upload or distribute downloaded content without the explicit permission of the original creator.'
  },
  {
    question: 'Can I use this service on my Android or iPhone?',
    answer: 'Yes, our website is fully responsive and works perfectly on any device, including Android and iOS. Simply open our website in your mobile browser to get started.'
  }
];

const FaqItem: React.FC<{ faq: typeof FAQ_DATA[0]; isOpen: boolean; onClick: () => void }> = ({ faq, isOpen, onClick }) => {
  return (
    <div className="border-b border-dark-border">
      <button
        onClick={onClick}
        className="w-full flex justify-between items-center text-left py-5 px-6 focus:outline-none"
      >
        <span className="text-lg font-medium text-light-text">{faq.question}</span>
        <span className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}>
           <i className={`fas ${isOpen ? 'fa-minus' : 'fa-plus'} text-primary`}></i>
        </span>
      </button>
      <div
        className={`grid transition-all duration-500 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
      >
        <div className="overflow-hidden">
             <div className="px-6 pb-5 text-medium-text">
                <p>{faq.answer}</p>
            </div>
        </div>
      </div>
    </div>
  );
};

const Faqs: React.FC = () => {
  const [openIndex, setOpenIndex] = React.useState<number | null>(0);

  const handleClick = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
        Frequently Asked <span className="text-primary">Questions</span>
      </h2>
      <div className="bg-dark-card rounded-lg border border-dark-border">
        {FAQ_DATA.map((faq, index) => (
          <FaqItem
            key={index}
            faq={faq}
            isOpen={openIndex === index}
            onClick={() => handleClick(index)}
          />
        ))}
      </div>
    </div>
  );
};

export default Faqs;