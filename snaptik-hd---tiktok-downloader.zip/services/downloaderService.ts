
import type { DownloadResult } from '../types';

// IMPORTANT: This is a mock service. A real TikTok downloader requires a server-side
// component to fetch the video data from TikTok's servers due to CORS policies.
// The frontend cannot do this directly. This function simulates that backend call.

export const fetchDownloadLinks = async (url: string): Promise<DownloadResult> => {
  console.log(`Fetching download links for: ${url}`);

  // Basic validation
  if (!url.includes('tiktok.com')) {
    throw new Error('Please enter a valid TikTok URL.');
  }

  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  // Return mock data
  return {
    thumbnailUrl: 'https://picsum.photos/seed/tiktok/500/800',
    videoUrl: 'https://storage.googleapis.com/web-dev-assets/video-and-source-tags/chrome.mp4',
    hdVideoUrl: 'https://storage.googleapis.com/web-dev-assets/video-and-source-tags/chrome.mp4',
    mp3Url: 'https://storage.googleapis.com/web-dev-assets/video-and-source-tags/chrome.mp4',
    author: '@coolcreator',
    title: 'Check out this amazing dance video! So much fun learning these moves. #fyp #dancechallenge',
  };
};
