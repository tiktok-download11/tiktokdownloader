
import * as React from 'react';

const PrivacyPage: React.FC = () => {
  return (
    <div className="py-16 bg-dark-bg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto prose prose-invert prose-lg text-medium-text prose-headings:text-light-text prose-strong:text-light-text prose-a:text-primary">
          <h1 className="text-4xl font-bold text-center mb-10">Privacy Policy</h1>
          <p>Last updated: October 26, 2023</p>
          <p>
            Your privacy is important to us. It is SnapTikHD's policy to respect your privacy regarding any information we may collect from you across our website.
          </p>
          
          <h3>1. Information We Collect</h3>
          <p>
            We do not collect or store any personally identifiable information from our users. The video URLs you paste into our service are processed on-the-fly and are not stored on our servers. We may collect anonymous usage data, such as browser type, device type, and session duration, for the sole purpose of improving our service. This data is aggregated and cannot be used to identify you.
          </p>

          <h3>2. Cookies</h3>
          <p>
            We use cookies to help us improve the user experience and for advertising purposes. Cookies are small files stored on your device. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.
          </p>

          <h3>3. Third-Party Services</h3>
          <p>
            We may use third-party services, such as Google AdSense, to display advertisements. These third-party ad servers or ad networks use technology to send, directly to your browser, the advertisements and links that appear on SnapTikHD. They automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit. Note that SnapTikHD has no access to or control over these cookies that are used by third-party advertisers.
          </p>
          
          <h3>4. Links to Other Sites</h3>
          <p>
            Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party's site. We strongly advise you to review the Privacy Policy of every site you visit. We have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services.
          </p>
          
          <h3>5. Changes to This Privacy Policy</h3>
          <p>
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPage;