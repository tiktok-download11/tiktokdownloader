
import * as React from 'react';
import { useParams, Link } from 'react-router-dom';
import { BLOG_POSTS } from '../constants';

const BlogPostPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const post = BLOG_POSTS.find((p) => p.slug === slug);

  if (!post) {
    return (
      <div className="py-16 text-center">
        <h1 className="text-4xl font-bold">Post not found</h1>
        <Link to="/blog" className="text-primary mt-4 inline-block">
          &larr; Back to Blog
        </Link>
      </div>
    );
  }

  return (
    <div className="py-16 bg-dark-bg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <article className="prose prose-invert prose-lg text-medium-text prose-headings:text-light-text prose-strong:text-light-text prose-a:text-primary">
            <div className="mb-8">
              <Link to="/blog" className="text-primary hover:underline">
                &larr; Back to Blog
              </Link>
              <h1 className="mt-4 !mb-2">{post.title}</h1>
              <p className="text-medium-text !mt-0">
                By {post.author} on {post.date}
              </p>
            </div>
            <img src={post.imageUrl} alt={post.title} className="w-full rounded-lg mb-8" />
            <div dangerouslySetInnerHTML={{ __html: post.content }} />
          </article>
        </div>
      </div>
    </div>
  );
};

export default BlogPostPage;