
import * as React from 'react';

const AboutPage: React.FC = () => {
  return (
    <div className="py-16 bg-dark-bg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto prose prose-invert prose-lg text-medium-text prose-headings:text-light-text prose-strong:text-light-text prose-a:text-primary">
          <h1 className="text-4xl font-bold text-center mb-10">About SnapTikHD</h1>
          <p>
            SnapTikHD was born from a simple idea: to create the fastest, simplest, and most reliable way for users to download their favorite TikTok content. We are a team of passionate developers and social media enthusiasts who recognized the need for a high-quality, watermark-free TikTok downloading service that respects both the user and the creator.
          </p>
          <p>
            Our mission is to provide a seamless experience, allowing you to save TikTok videos, stories, and sounds for offline viewing, creative projects, or simply to keep a personal archive of content you love. We believe in keeping our tool free and accessible to everyone, supported by non-intrusive advertising.
          </p>
          <h3>Our Core Principles</h3>
          <ul>
            <li><strong>User-First Design:</strong> Our website is designed to be intuitive and easy to use on any device. No confusing buttons or pop-ups.</li>
            <li><strong>Quality is Key:</strong> We always strive to provide the highest quality downloads possible, ensuring you get the video just as the creator intended.</li>
            <li><strong>Privacy Matters:</strong> We do not track your downloads or store your personal information. Your privacy is paramount.</li>
            <li><strong>Respect for Creators:</strong> We strongly encourage our users to respect copyright and the hard work of content creators. Always give credit where it's due and ask for permission before reusing content for commercial purposes.</li>
          </ul>
          <p>
            Thank you for choosing SnapTikHD. We are constantly working to improve our service and welcome any feedback you may have.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;