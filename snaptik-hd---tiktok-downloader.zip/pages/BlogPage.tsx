
import * as React from 'react';
import { Link } from 'react-router-dom';
import { BLOG_POSTS } from '../constants';

const BlogPage: React.FC = () => {
  return (
    <div className="py-16 bg-dark-bg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-light-text mb-4">Our Blog</h1>
          <p className="text-lg text-medium-text">
            Tips, tricks, and trends from the world of TikTok.
          </p>
        </div>
        <div className="max-w-4xl mx-auto grid gap-12">
          {BLOG_POSTS.map((post) => (
            <div
              key={post.slug}
              className="group flex flex-col md:flex-row gap-6 bg-dark-card border border-dark-border rounded-lg p-6 hover:border-primary transition-all duration-300"
            >
              <div className="md:w-1/3">
                <Link to={`/blog/${post.slug}`}>
                  <img
                    src={post.imageUrl}
                    alt={post.title}
                    className="w-full h-48 object-cover rounded-md group-hover:opacity-80 transition-opacity duration-300"
                  />
                </Link>
              </div>
              <div className="md:w-2/3">
                <p className="text-sm text-medium-text mb-2">
                  {post.date} &bull; {post.author}
                </p>
                <h2 className="text-2xl font-bold text-light-text mb-3">
                  <Link
                    to={`/blog/${post.slug}`}
                    className="group-hover:text-primary transition-colors duration-300"
                  >
                    {post.title}
                  </Link>
                </h2>
                <p className="text-medium-text mb-4 line-clamp-3">{post.excerpt}</p>
                <Link
                  to={`/blog/${post.slug}`}
                  className="font-semibold text-primary group-hover:underline"
                >
                  Read more &rarr;
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogPage;