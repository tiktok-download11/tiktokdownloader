
import * as React from 'react';
import DownloadForm from '../components/DownloadForm';
import DownloadResultCard from '../components/DownloadResult';
import Faqs from '../components/Faqs';
import SeoArticle from '../components/SeoArticle';
import { useDownloader } from '../hooks/useDownloader';
import AdPlaceholder from '../components/AdPlaceholder';

const HomePage: React.FC = () => {
  const { isLoading, error, result, startDownload, reset } = useDownloader();

  return (
    <div className="bg-dark-bg min-h-screen text-light-text">
      {/* Hero Section */}
      <section className="py-20 md:py-28 bg-gradient-to-br from-dark-bg via-dark-card to-dark-bg">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4">
            TikTok Video Downloader
          </h1>
          <p className="text-lg md:text-xl text-medium-text max-w-3xl mx-auto mb-8">
            Download TikTok videos, stories, and slideshows in HD without any watermark. Fast, free, and simple. Just paste the link below.
          </p>
          
          <div className="mt-8">
            {error && <p className="text-red-400 mb-4 animate-fade-in">{error}</p>}
            {!result ? (
              <DownloadForm isLoading={isLoading} onDownload={startDownload} />
            ) : (
              <DownloadResultCard result={result} onReset={reset} />
            )}
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col lg:flex-row gap-12">

          {/* Left Column: Features & Article */}
          <div className="lg:w-2/3">
            {/* Features Section */}
            <section className="mb-16">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div className="bg-dark-card p-6 rounded-lg border border-dark-border">
                  <i className="fas fa-tint-slash text-5xl text-primary mb-4"></i>
                  <h3 className="text-xl font-bold mb-2">No Watermark</h3>
                  <p className="text-medium-text">Get clean videos, perfect for sharing and archiving.</p>
                </div>
                <div className="bg-dark-card p-6 rounded-lg border border-dark-border">
                  <i className="fas fa-hdd text-5xl text-primary mb-4"></i>
                  <h3 className="text-xl font-bold mb-2">HD Quality</h3>
                  <p className="text-medium-text">Download videos in the highest possible resolution.</p>
                </div>
                <div className="bg-dark-card p-6 rounded-lg border border-dark-border">
                  <i className="fas fa-file-audio text-5xl text-primary mb-4"></i>
                  <h3 className="text-xl font-bold mb-2">MP3 Conversion</h3>
                  <p className="text-medium-text">Extract and download audio from any TikTok video.</p>
                </div>
              </div>
            </section>
            
            <section className="mb-16">
              <SeoArticle />
            </section>
          </div>

          {/* Right Column: Ads & FAQs */}
          <div className="lg:w-1/3">
            <aside className="sticky top-20 space-y-8">
              <AdPlaceholder width="100%" height="250px" label="Sidebar Top Ad" />
              <Faqs />
              <AdPlaceholder width="100%" height="250px" label="Sidebar Bottom Ad" />
            </aside>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;