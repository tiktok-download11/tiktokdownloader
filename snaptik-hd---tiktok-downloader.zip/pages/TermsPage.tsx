
import * as React from 'react';

const TermsPage: React.FC = () => {
  return (
    <div className="py-16 bg-dark-bg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto prose prose-invert prose-lg text-medium-text prose-headings:text-light-text prose-strong:text-light-text prose-a:text-primary">
          <h1 className="text-4xl font-bold text-center mb-10">Terms of Use</h1>
          <p>Last updated: October 26, 2023</p>
          <p>
            By accessing and using SnapTikHD (the "Service"), you agree to be bound by these Terms of Use ("Terms"). If you disagree with any part of the terms, you may not access the Service.
          </p>

          <h3>1. Use of Service</h3>
          <p>
            Our Service allows you to download publicly available video content from TikTok for personal, non-commercial use. You are solely responsible for ensuring that your use of the content does not infringe on any copyright, privacy, or other rights of the original creator or any third party.
          </p>

          <h3>2. Intellectual Property</h3>
          <p>
            The Service and its original content, features, and functionality are and will remain the exclusive property of SnapTikHD and its licensors. The content downloaded from TikTok is the property of the respective content creators. Our service does not grant you any rights to this content. You must not use any downloaded content for commercial purposes without obtaining a license to do so from the content creators.
          </p>
          
          <h3>3. Disclaimer</h3>
          <p>
            The Service is provided "as is". SnapTikHD makes no warranties, expressed or implied, and hereby disclaims all other warranties including, without limitation, implied warranties of merchantability, fitness for a particular purpose, or non-infringement of intellectual property. We do not host any pirated or copyrighted content on our servers.
          </p>

          <h3>4. Limitation of Liability</h3>
          <p>
            In no event shall SnapTikHD be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on our website, even if we have been notified orally or in writing of the possibility of such damage.
          </p>

          <h3>5. Changes to Terms</h3>
          <p>
            We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of any changes by posting the new Terms on this page.
          </p>
        </div>
      </div>
    </div>
  );
};

export default TermsPage;