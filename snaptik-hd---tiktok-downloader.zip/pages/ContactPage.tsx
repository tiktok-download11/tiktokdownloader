
import * as React from 'react';

const ContactPage: React.FC = () => {
  return (
    <div className="py-16 bg-dark-bg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-light-text mb-4">Contact Us</h1>
            <p className="text-lg text-medium-text mb-8">
              Have a question, suggestion, or a business inquiry? We'd love to hear from you.
            </p>
          </div>
          <form className="bg-dark-card border border-dark-border rounded-lg p-8 space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-light-text mb-2">
                Your Name
              </label>
              <input
                type="text"
                name="name"
                id="name"
                className="w-full bg-dark-bg border border-dark-border rounded-md py-3 px-4 text-light-text focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="John Doe"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-light-text mb-2">
                Your Email
              </label>
              <input
                type="email"
                name="email"
                id="email"
                className="w-full bg-dark-bg border border-dark-border rounded-md py-3 px-4 text-light-text focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-light-text mb-2">
                Message
              </label>
              <textarea
                name="message"
                id="message"
                rows={4}
                className="w-full bg-dark-bg border border-dark-border rounded-md py-3 px-4 text-light-text focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Your message..."
              ></textarea>
            </div>
            <div className="text-center">
              <button
                type="submit"
                className="bg-primary text-dark-bg font-bold py-3 px-8 rounded-full hover:bg-opacity-80 transition-colors duration-300"
              >
                Send Message
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;