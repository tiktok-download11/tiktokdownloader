
import * as React from 'react';
import type { DownloadResult } from '../types';
import { fetchDownloadLinks } from '../services/downloaderService';

export const useDownloader = () => {
  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  const [error, setError] = React.useState<string | null>(null);
  const [result, setResult] = React.useState<DownloadResult | null>(null);

  const startDownload = React.useCallback(async (url: string) => {
    if (!url) {
      setError('Please paste a TikTok URL first.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setResult(null);
    try {
      const downloadResult = await fetchDownloadLinks(url);
      setResult(downloadResult);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  const reset = React.useCallback(() => {
    setIsLoading(false);
    setError(null);
    setResult(null);
  }, []);

  return {
    isLoading,
    error,
    result,
    startDownload,
    reset
  };
};